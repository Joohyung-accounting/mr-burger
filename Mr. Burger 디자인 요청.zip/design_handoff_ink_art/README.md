# Handoff: Mr. Burger — 손그림(잉크 & 수채) 아트 교체

## Overview

Mr. Burger(`Joohyung-accounting/mr-burger`)의 캔버스 아트를 **손으로 그린 잉크 & 수채 스타일**로 전면 교체합니다.
기존 아트는 깔끔한 벡터 도형이라 "기계로 찍어낸" 느낌이 강했습니다. 이 교체본은 모든 윤곽을 흔들린
폴리라인으로 그리고, 색을 선 밖으로 살짝 어긋나게 칠하고, 그라디언트 대신 손해칭으로 음영을 냅니다.

동시에 **버거 레이어 아트와 재료 상자 아트를 분리**합니다. 상자 안에 든 것은 슬라이스가 아니라
통재료(반으로 가른 아보카도, 꼭지 달린 통토마토, 소스 병)여야 하기 때문입니다.

## About the Design Files

⚠️ **이 핸드오프는 일반적인 "HTML 목업 → 코드로 재구현"이 아닙니다.**

이 번들의 `www/js/art.js`는 **디자인 참고물이 아니라 실제로 동작하는 프로덕션 소스**입니다.
기존 `www/js/art.js`와 동일한 IIFE 구조, 동일한 `window.Art` 공개 API, 동일한 레이어 비율을 갖도록
작성됐습니다. 다시 구현하지 말고 **그대로 덮어쓰세요.**

`preview/` 폴더의 HTML은 그 art.js가 실제로 무엇을 그리는지 눈으로 확인하기 위한 참고용 뷰어일 뿐입니다.
게임에 옮길 필요 없습니다.

## Fidelity

**High-fidelity (프로덕션 코드).** 색상·비율·펜 두께 모두 최종값입니다.

---

## 적용 절차 (2단계)

### 1단계 — art.js 덮어쓰기 (코드 수정 없음)

```
cp design_handoff_ink_art/www/js/art.js  www/js/art.js
```

이것만으로 다음이 전부 새 아트로 바뀝니다:

- 버거 레이어 13종 + 소스 5종 (`drawLayer` / `drawStack` / `drawIcon`)
- 요리사 (`drawChef` — 치비 비율·볼터치·눈깜빡임·스쿼시 점프 동작 모두 유지)
- 굽기 단계 (`done` / `char` 파라미터 동작 그대로)

`game.js`, `core.js`, `test/core.test.js`, `test/smoke.test.js` **수정 불필요**.
공개 API와 모든 `hFrac` / `wFrac` 값이 원본과 완전히 동일합니다.

### 2단계 — 재료 상자만 game.js 한 곳 교체

`www/js/game.js`의 `drawCrates()` 안, 내부 클립(`ctx.clip()`) 직후 블록을 교체합니다.

**지우는 코드 (현재 game.js):**

```js
      /* Stack as many as it takes to fill the box. A fixed count left a tub of
         sauce looking empty (it is 2px tall) while buns overflowed it. */
      var hFrac = Math.max(0.04, Art.heightOf(id, 1));
      var iw = Math.min(w.w - 4, (w.h * 0.42) / hFrac);
      var ih = hFrac * iw;
      var step = Math.max(1.5, ih * 0.74);
      var count = clamp(Math.round((w.h * 0.58) / step), 2, 6);
      var base = w.y + w.h + ih * 0.35;
      for (var k = count - 1; k >= 0; k--) {
        ctx.globalAlpha = k === 0 ? 1 : Math.max(0.45, 0.92 - k * 0.1);
        Art.drawLayer(ctx, id, w.x + w.w / 2, base - ih - k * step, iw, raw);
      }
      ctx.globalAlpha = 1;
```

**넣는 코드:**

```js
      /* The crate holds the INGREDIENT, not a pile of burger layers: half an
         avocado with the stone in, a whole tomato with its calyx, a bottle of
         ketchup. Art.drawPortrait draws that; it falls back to the layer art
         for anything without a portrait of its own. */
      ctx.translate(w.x, w.y + w.h * 0.04);
      Art.drawPortrait(ctx, id, w.w, w.h * 0.96);
      ctx.translate(-w.x, -(w.y + w.h * 0.04));
```

아래의 `var sg = ctx.createLinearGradient(...)` (안쪽 그림자)부터는 그대로 둡니다.

**부수 효과**
- `raw` 변수가 이 블록에서만 쓰였다면 미사용 변수가 됩니다. 지워도 되고 둬도 무해합니다.
- 상자에서 재료가 날아가는 연출(`pullFromBox` → `S.flyers` → `drawFlyers`)은 **레이어 아트를 계속 사용**합니다.
  꺼내는 순간 손에 들리는 건 버거에 올라갈 슬라이스라서 그게 맞습니다.
- 상점 아이콘 `Art.drawIcon(g, ing.id, 64, 34)`도 원하면 `drawPortrait`로 바꿀 수 있지만,
  그 자리는 가로로 납작해서 레이어 아트가 더 잘 맞습니다.

---

## Public API

기존과 동일 (추가분만 표시):

| 함수 | 상태 |
|---|---|
| `Art.rr / hash / grad / mixHex` | 동일 |
| `Art.heightOf / layerWidth / stackHeight / fitWidth` | 동일 |
| `Art.drawLayer / drawStack / drawIcon / drawChef` | 동일 시그니처, 새 아트 |
| `Art.SAUCES / has` | 동일 |
| **`Art.drawPortrait(ctx, id, w, h)`** | **신규** — 통재료 초상. 초상이 없는 id는 `drawIcon`으로 폴백 |
| **`Art.ink / hatch / trace / rectPts / ellPts / blobPts / crescentPts / INK`** | **신규** — 손그림 툴킷. game.js의 조리대·그릴·상자를 같은 펜으로 다시 그리고 싶을 때 사용 |

## 렌더링 원리 — 반드시 유지할 것

1. **흔들림은 결정적(deterministic)이어야 합니다.**
   모든 지터는 기존 `hash()` 시드에서 나옵니다. `Math.random()`을 쓰면 매 프레임 선이 요동쳐서
   (boiling) 요리사가 걸을 때 화면이 지글거립니다. `wob(seed, i)` 헬퍼를 쓰세요.

2. **펜 두께는 크기 비례입니다.** `pen(w, h) = max(0.9, min(w*0.017, h*0.30))`.
   6px 소스 밴드와 40px 빵이 같은 선 굵기를 쓰면 소스가 통째로 잉크가 됩니다.

3. **레이어는 자기 밴드보다 크게 그려도 됩니다.**
   `hFrac`/`wFrac`은 **쌓이는 높이**만 정합니다. 양상추는 빵보다 넓게(`wFrac 1.10`), 치즈는
   밴드보다 높게(`H = h * 2.0`) 그려서 아래 레이어를 덮습니다. 이게 없으면 납작해 보입니다.

4. **작은 크기 폴백.** 할라피뇨는 링 반지름이 3.2px 미만이면 구멍과 심지를 생략합니다.
   44px 재료통에서 서브픽셀 디테일은 초록 별표로 뭉개집니다.

## Design Tokens

### 펜
| 이름 | 값 | 용도 |
|---|---|---|
| `INK` | `#4a3226` | 기본 펜 선 |
| `INK_SOFT` | `#6b4a37` | 두 번째 흐린 패스 |
| 색 어긋남(off-register) | 도형 폭의 0.4~0.8% | 채움을 선 밖으로 밀어내는 양 |
| 해칭 알파 | 0.16 ~ 0.30 | 그늘 |

### 재료 색 (레이어)
| 재료 | 본색 | 선/그늘 |
|---|---|---|
| 빵 | `#eab470` / `#e8b46f` | `#8f5a24`, 해칭 `#a4692c` |
| 참깨 | `#fff4dd` | `#a8763f` |
| 패티(생) | `#e08c83` | 옆면 `#a8564c` |
| 패티(익음) | `#8f5731` | 옆면 `#532c1a` |
| 패티(탐) | 위 색 × `#3a2a20` 블렌드 | `#1c1210` |
| 치즈 | `#f7c343` | `#a86f08`, 구멍 `#b07607` |
| 양상추 | `#84c25c` / `#9ad46e` | `#3f7a2a` |
| 토마토 | `#ef5346` | 옆면 `#b8271f`, 선 `#9e2019`, 과육 `#fbc0b2`, 씨 `#f2cf7a` |
| 양파 | `#d9c0ea` | `#9b74c0` |
| 피클 | `#c2cc4e` | `#5f7a1e`, 속 `#e6ee9e` |
| 베이컨 | `#c9503a` | `#7d2818`, 지방 `#ffcfc2` |
| 할라피뇨 | `#2f7d2b` | `#17470f`, 심지 `#f2f8d8`, 씨 `#e8d98a` |
| 계란 | 흰자 `#fffaee` / 노른자 `#f9c53c` | `#cbb794` / `#e08f13` |
| 아보카도 | 과육 `#cfe08f` | 껍질 `#3f5d28` |

### 소스 (로프 렌더링)
| 소스 | 본색 | 어두운 선 | 문양 |
|---|---|---|---|
| ketchup | `#d62828` | `#8f1c1c` | 굵은 지그재그 |
| mustard | `#f0bc18` | `#a87d09` | 가늘고 촘촘한 지그재그 |
| mayo | `#fbf3dd` | `#c9b98d` | 통통한 방울이 이어진 굵은 줄 |
| bbq | `#a45520` | `#5c2a0c` | 넓은 웅덩이 + 앞쪽 드립 (※ 어두운 상자 안에서 묻히지 않도록 실제 BBQ보다 밝게 잡음) |
| special | `#ff8fab` | `#c65f7c` | 가는 드리즐 + 흩뿌린 점 |

소스는 납작한 띠가 아니라 **3겹 스트로크**로 그립니다: 어두운 테두리 → 본색 → 위쪽 흰 하이라이트.

### 요리사
| 부위 | 색 |
|---|---|
| 조리복 | `#fffaf0`, 해칭 `#c3ac91` |
| 바지 | `#7a5a8a` |
| 스카프 | `#ef7d6b` |
| 피부 | `#f7cfa4`, 해칭 `#c99a6d` |
| 볼터치 | `#f4948a` (알파 0.5) |
| 토크 | `#ffffff` / `#fffdf7` |
| 눈·입 | `#4a3226` |

## 재료 구분 원칙 (초록 재료 충돌 해결)

초기안에서 피클·아보카도·할라피뇨·양상추가 전부 "초록 타원 여러 개"라 구분이 안 됐습니다.
**실루엣**을 서로 다르게 갈랐습니다 — 색만 바꾸면 흑백/작은 크기에서 다시 뭉개집니다.

| 재료 | 실루엣 | 명도 |
|---|---|---|
| 양상추 | 주름진 잎 3장이 겹침 (유일한 연속 띠) | 중간 |
| 피클 | 크링클컷 동전 3개 + 씨앗 | 밝은 올리브 |
| 아보카도 | **초승달** 3개 + 바깥 곡선의 짙은 껍질선 | 가장 밝음 |
| 할라피뇨 | **구멍 뚫린 링** 3개 + 심지 + 씨 | 가장 어두움 |

## Files

```
design_handoff_ink_art/
├── README.md                 ← 이 문서
├── www/js/art.js             ← 덮어쓸 프로덕션 파일
└── preview/
    ├── 게임 아트 교체본.dc.html  ← 참고용 뷰어 (게임에 옮기지 말 것)
    └── support.js
```

원본 저장소: `Joohyung-accounting/mr-burger` (branch `main`)
