# Handoff: Mr. Burger — 손그림(잉크 & 수채) 아트 전면 교체

## Overview

Mr. Burger(`Joohyung-accounting/mr-burger`)의 캔버스 아트를 **손으로 그린 잉크 & 수채 스타일**로
교체합니다. 기존 아트는 깔끔한 벡터 도형이라 "기계로 찍어낸" 느낌이 강했습니다. 이 교체본은 모든
윤곽을 흔들린 폴리라인으로 그리고, 색을 선 밖으로 살짝 어긋나게 칠하고, 그라디언트 대신 손해칭으로
음영을 냅니다.

이번 판에는 재료뿐 아니라 **주방 전체(바닥·벽·조리대·그릴·접시·창구·쓰레기통)** 와
**손님 캐릭터 14종**, 그리고 **재료 상자용 통재료 초상**이 포함됩니다.

## About the Design Files

⚠️ **이 핸드오프는 일반적인 "HTML 목업 → 코드로 재구현"이 아닙니다.**

이 번들의 `www/js/art.js`는 **디자인 참고물이 아니라 실제로 동작하는 프로덕션 소스**입니다.
기존 `www/js/art.js`와 동일한 IIFE 구조, 동일한 `window.Art` 공개 API, 동일한 레이어 비율을 갖도록
작성됐습니다. 다시 구현하지 말고 **그대로 덮어쓰세요.**

`preview/` 폴더의 두 HTML은 그 art.js가 실제로 무엇을 그리는지 눈으로 확인하기 위한 뷰어입니다.
게임에 옮길 필요 없습니다.

## Fidelity

**High-fidelity (프로덕션 코드).** 색상·비율·펜 두께 모두 최종값입니다.

---

# 적용 절차

## 1단계 — art.js 덮어쓰기 (다른 코드 수정 없음)

```
cp design_handoff_ink_art/www/js/art.js  www/js/art.js
```

이것만으로 다음이 전부 새 아트로 바뀝니다:

- 버거 레이어 13종 + 소스 5종 (`drawLayer` / `drawStack` / `drawIcon`)
- 요리사 (`drawChef` — 치비 비율·볼터치·눈깜빡임·스쿼시 점프 동작 모두 유지)
- 굽기 단계 (`done` / `char` 파라미터 동작 그대로)

`game.js`, `core.js`, `test/core.test.js`, `test/smoke.test.js` **수정 불필요**.
공개 API와 모든 `hFrac` / `wFrac` 값이 원본과 동일합니다.

> **주의 — 아래 번 아트가 바뀝니다.** 기존 art.js에는 `LAYERS.bun = LAYERS.bunTop` 한 줄이 있어서
> 아래 번이 참깨 왕관(위 번)으로 그려지고 있었습니다. 즉 모든 버거가 뚜껑 두 장을 겹친 모양이었어요.
> 교체본은 `bun`을 **힐(heel)** 로 따로 그립니다 — 아랫면이 둥글고 윗면에 옅은 자른 면, 참깨 없음.
> `hFrac`이 `0.40` → `0.20`으로 줄어드는 유일한 값 변경이며, 스택 높이 계산은 자동으로 따라갑니다.

## 2단계 — 재료 상자: game.js 한 곳 교체

상자 안을 "버거 레이어를 여러 장 쌓은 모습"에서 "통재료 한 개"로 바꿉니다.
`www/js/game.js`의 `drawCrates()` 안, 내부 클립(`ctx.clip()`) 직후 블록입니다.

**지우는 코드**

```js
      /* Stack as many as it takes to fill the box. A fixed count left a tub of
         sauce looking empty (it is 2px tall) while buns overflowed it. */
      var hFrac = Math.max(0.04, Art.heightOf(id, 1));
      var iw = Math.min(w.w - 4, (w.h * 0.42) / hFrac);
      var ih = hFrac * iw;
      var step = Math.max(1.5, ih * 0.74);
      var count = clamp(Math.round((w.h * 0.58) / step), 2, 6);
      var base = w.y + w.h + ih * 0.35;
      for (var k = count - 1; k >= 0; k--) {
        ctx.globalAlpha = k === 0 ? 1 : Math.max(0.45, 0.92 - k * 0.1);
        Art.drawLayer(ctx, id, w.x + w.w / 2, base - ih - k * step, iw, raw);
      }
      ctx.globalAlpha = 1;
```

**넣는 코드**

```js
      /* The crate holds the INGREDIENT, not a pile of burger layers: half an
         avocado with the stone in, a whole tomato with its calyx, a bottle of
         ketchup. Art.drawPortrait draws that; it falls back to the layer art
         for anything without a portrait of its own. */
      ctx.translate(w.x, w.y + w.h * 0.04);
      Art.drawPortrait(ctx, id, w.w, w.h * 0.96);
      ctx.translate(-w.x, -(w.y + w.h * 0.04));
```

아래의 `var sg = ctx.createLinearGradient(...)` (안쪽 그림자)부터는 그대로 둡니다.

부수 효과: `raw` 변수가 이 블록에서만 쓰였다면 미사용 변수가 됩니다(지워도 되고 둬도 무해).
상자에서 재료가 날아가는 연출(`pullFromBox` → `S.flyers` → `drawFlyers`)은 **레이어 아트를 계속 사용**
합니다 — 손에 들리는 건 버거에 올라갈 슬라이스니까요.

## 3단계 — 주방 사물: game.js 그리기 코드만 교체 (선택)

`Art.scene.*`이 새로 생깁니다. **좌표·크기 계산은 건드리지 말고**, 각 함수 안에서 도형을 칠하는
부분만 아래 호출로 바꾸세요.

| game.js 함수 | 바꿀 대상 | 새 호출 |
|---|---|---|
| `drawRoom()` | 바닥 사각형 + 체커 | `Art.scene.floor(ctx, x, y, w, h, T, tile)` |
| `drawRoom()` | 뒷벽 | `Art.scene.wall(ctx, x, y, w, h, T)` |
| `drawCounter()` | `slab(...)` 호출 | `Art.scene.counter(ctx, x, y, w, h, depth, T)` |
| `drawCrates()` | 상자 몸통 | `Art.scene.crate(ctx, x, y, w, h, T)` |
| `drawGrill()` | 그릴 몸통·살 | `Art.scene.grill(ctx, x, y, w, h, { hot })` |
| `drawPlates()` | 접시 타원 | `Art.scene.plate(ctx, cx, cy, w, { glow })` |
| `drawHatchAndBin()` | 창구 | `Art.scene.hatch(ctx, x, y, w, h, T, { lit })` |
| `drawHatchAndBin()` | 쓰레기통 | `Art.scene.bin(ctx, x, y, w, h, { open })` |

`T`는 테마 객체입니다. game.js가 이미 갖고 있는 6개 주방 팔레트에 1:1로 대응하는
`Art.scene.THEMES.diner / tiles / sunset / night / brass / harbour`를 쓰거나,
같은 키(`top` / `top2` / `side`)를 가진 기존 `D` 객체를 그대로 넘겨도 동작합니다
(`floorA` / `floorB` / `grout` / `wall` / `wallLine` / `trim` 키가 추가로 필요합니다).

옵션 값:
- `grill`의 `hot` 0~1 — 살 색이 회색→주황으로 섞이고 아지랑이가 올라옵니다. 굽는 중일 때 1.
- `plate`의 `glow` 0~1 — 완성된 접시에 노란 후광.
- `hatch`의 `lit` 0~1 — 창구 안쪽이 밝아집니다.
- `bin`의 `open` 0~1 — 뚜껑이 젖혀집니다. 버릴 때 잠깐 1로 튕기면 좋습니다.

## 4단계 — 손님 캐릭터: 이모지 대체 (선택)

주문 전표의 손님이 지금은 이모지(`🧔` 등)입니다. `Art.drawGuest`로 바꾸면 요리사와 같은 펜으로
그려진 실제 캐릭터가 나옵니다.

```js
// 전신 (창구에서 기다리는 손님 등)
Art.drawGuest(ctx, x, feetY, s, { type: 'builder', bob: t, blink: b, mood: 1 });

// 전표용 얼굴 컷 (캔버스 하나를 통째로 채움)
Art.drawGuestFace(ctx, 'builder', w, h, { mood: 1 });
```

`s`는 `drawChef`에 넘기는 것과 같은 스케일 숫자입니다. 타입 14종은 `Art.GUESTS` 배열에 있습니다:

```
baby, kid, student, teen, athlete, courier, builder,
police, nurse, office, artist, farmer, granny, grandpa
```

`mood`는 1(웃음) ~ 0(찌푸림)으로, 인내심 바가 줄어들면 같이 낮춰주면 표정이 굳습니다.

전표 HTML에서 `.who`의 이모지를 `<canvas class="who-face" width="80" height="56">`로 바꾸고
티켓을 만들 때 위 함수를 한 번 호출하면 됩니다.

---

# Public API

기존과 동일 (추가·변경분만 표시):

| 함수 | 상태 |
|---|---|
| `Art.rr / hash / grad / mixHex` | 동일 |
| `Art.heightOf / layerWidth / stackHeight / fitWidth` | 동일 |
| `Art.drawLayer / drawStack / drawIcon / drawChef` | 동일 시그니처, 새 아트 |
| `Art.SAUCES / has` | 동일 |
| `Art.drawPortrait(ctx, id, w, h)` | **신규** — 통재료 초상. 초상 없는 id는 `drawIcon` 폴백 |
| `Art.scene.*` | **신규** — floor / wall / counter / crate / grill / plate / hatch / bin / THEMES |
| `Art.drawGuest(ctx, x, y, s, opts)` | **신규** — 손님 전신 |
| `Art.drawGuestFace(ctx, id, w, h, opts)` | **신규** — 손님 얼굴 컷 |
| `Art.GUESTS` | **신규** — 손님 타입 id 배열 |
| `Art.ink / hatch / trace / rectPts / ellPts / blobPts / crescentPts / INK` | **신규** — 손그림 툴킷 |

# 렌더링 원리 — 반드시 유지할 것

1. **흔들림은 결정적(deterministic)이어야 합니다.**
   모든 지터는 기존 `hash()` 시드에서 나옵니다. `Math.random()`을 쓰면 매 프레임 선이 요동쳐서
   (boiling) 요리사가 걸을 때 화면이 지글거립니다. `wob(seed, i)` 헬퍼를 쓰세요.

2. **펜 두께는 크기 비례입니다.** `pen(w, h) = max(0.9, min(w*0.017, h*0.30))`.
   6px 소스 밴드와 40px 빵이 같은 선 굵기를 쓰면 소스가 통째로 잉크가 됩니다.

3. **레이어는 자기 밴드보다 크게 그려도 됩니다.**
   `hFrac`/`wFrac`은 **쌓이는 높이**만 정합니다. 양상추는 빵보다 넓게(`wFrac 1.10`), 치즈는
   밴드보다 높게(`H = h * 2.0`) 그려서 아래 레이어를 덮습니다. 이게 없으면 납작해 보입니다.

4. **작은 크기 폴백.** 할라피뇨는 링 반지름이 3.2px 미만이면 구멍과 심지를 생략합니다.
   44px 재료통에서 서브픽셀 디테일은 초록 별표로 뭉개집니다.

5. **손님은 머리 위에서만 구분됩니다.**
   헤어/모자는 두피 위쪽(`hy - hr*0.60` 중심)에 얕게 그려 헤어라인에서 끝나야 합니다. 더 아래로
   내려오면 눈(`hy - hr*0.02`)을 덮어 얼굴이 사라집니다.

# Design Tokens

### 펜
| 이름 | 값 | 용도 |
|---|---|---|
| `INK` | `#4a3226` | 기본 펜 선 |
| `INK_SOFT` | `#6b4a37` | 두 번째 흐린 패스 |
| 색 어긋남(off-register) | 도형 폭의 0.4~0.8% | 채움을 선 밖으로 밀어내는 양 |
| 해칭 알파 | 0.10 ~ 0.30 | 그늘 |

### 재료 색 (레이어)
| 재료 | 본색 | 선/그늘 |
|---|---|---|
| 아래 번(heel) | `#e0a75f`, 자른 면 `#f6dcae` | `#8f5a24`, 해칭 `#a4692c` |
| 위 번(crown) | `#eab470`, 참깨 `#fff4dd` | `#a4692c` / `#a8763f` |
| 패티(생) | `#e08c83` | 옆면 `#b2504a` |
| 패티(익음) | `#8f5731` | 옆면 `#532c1a` |
| 패티(탐) | 위 색 × `#3a2a20` 블렌드 | `#1c1210` |
| 치즈 | `#f7c343` | `#a86f08`, 구멍 `#b07607` |
| 양상추 | `#84c25c` / `#9ad46e` | `#3f7a2a` |
| 토마토 | `#ef5346` | 옆면 `#b8271f`, 과육 `#fbc0b2`, 씨 `#f2cf7a` |
| 양파 | `#d3b0e8` | `#7d4fa8` |
| 피클 | `#6f9a34` | `#33500f`, 줄무늬 `#9dc456` |
| 베이컨 | `#c9503a` | `#7d2818`, 지방 `#ffcfc2` |
| 할라피뇨 | `#2f7d2b` / `#3a8f2c` | `#17470f`, 심지 `#f2f8d8`, 씨 `#e8d98a` |
| 계란 | 흰자 `#fdf3e0` / 노른자 `#f9c53c` | `#b9a17c` / `#e08f13` |
| 아보카도 | 과육 `#d9e8a2` | 껍질 `#3f5d28`, 씨 `#a4703f` |

### 소스 (로프 렌더링 — 어두운 테두리 → 본색 → 위쪽 흰 하이라이트 3겹)
| 소스 | 본색 | 어두운 선 | 문양 |
|---|---|---|---|
| ketchup | `#d62828` | `#8f1c1c` | 굵은 지그재그 |
| mustard | `#f0bc18` | `#a87d09` | 가늘고 촘촘한 지그재그 |
| mayo | `#fbf3dd` | `#c9b98d` | 통통한 방울이 이어진 굵은 줄 |
| bbq | `#7a3b18` | `#3d1c08` | 넓은 웅덩이 + 앞쪽 드립 |
| special | `#ff8fab` | `#c65f7c` | 가는 드리즐 + 흩뿌린 점 |

### 주방 테마 (`Art.scene.THEMES`)
| 테마 | floorA / floorB | grout | top / top2 / side | trim |
|---|---|---|---|---|
| diner | `#e8d5b8` / `#c9a87d` | `#a8845a` | `#e4c496` / `#d2ad7c` / `#a97d4e` | `#c0562f` |
| tiles | `#e4ece4` / `#b9cbbd` | `#8ba394` | `#cfd9d0` / `#b6c3b8` / `#7d8d81` | `#4f8f7a` |
| sunset | `#f7dfd2` / `#e0b0a0` | `#b8877a` | `#e8bfb4` / `#d6a396` / `#a3705f` | `#d2603f` |
| night | `#ddd4ec` / `#b3a6cf` | `#8b7cae` | `#cfc7e4` / `#b6aad2` / `#7d709b` | `#6a4fa3` |
| brass | `#efe0b6` / `#cbb883` | `#a08f5c` | `#ddcb92` / `#c6b276` / `#8f7c46` | `#b08420` |
| harbour | `#e2ecf2` / `#b5c8d6` | `#8ba0b0` | `#c6d5e0` / `#adbfcd` / `#728799` | `#3f6f92` |

`top` / `top2` / `side` 세 키는 game.js의 기존 `counterTop` / `counterTop2` / `counterSide`와 같은 값입니다.

### 요리사
| 부위 | 색 |
|---|---|
| 조리복 | `#fffaf0`, 해칭 `#c3ac91` |
| 바지 | `#7a5a8a` |
| 스카프 | `#ef7d6b` |
| 피부 | `#f7cfa4`, 해칭 `#c99a6d` |
| 볼터치 | `#f4948a` (알파 0.5) |
| 눈·입 | `#4a3226` |

# 재료 구분 원칙 (초록 재료 충돌 해결)

초기안에서 피클·아보카도·할라피뇨·양상추가 전부 "초록 타원 여러 개"라 구분이 안 됐습니다.
**실루엣**을 서로 다르게 갈랐습니다 — 색만 바꾸면 흑백/작은 크기에서 다시 뭉개집니다.

| 재료 | 버거 레이어 실루엣 | 재료 상자 초상 |
|---|---|---|
| 양상추 | 주름진 잎 3장이 겹침 | 겉잎이 감싼 통양상추 |
| 피클 | 크링클컷 동전 3개 + 씨앗 | 사마귀 있는 통 딜피클 |
| 아보카도 | 초승달 3개 + 짙은 껍질선 | 반으로 갈라 씨가 보이는 반쪽 |
| 할라피뇨 | 구멍 뚫린 링 3개 + 심지 + 씨 | 어깨가 두툼하고 꼭지가 꺾인 통고추 |

# 인터페이스 방향 (아직 코드 아님)

`preview/주방과 UI 디자인.dc.html` 아래쪽에 타이틀 / HUD·주문판 / 영수증 / 상점 4개 화면의
목업이 있습니다. 방향은 **어두운 유리판 → 주문 전표 종이**입니다:

- 크림 종이 `#fdf6e6`, 잉크 글씨 `#3f2a1c`, 보조 `#a08a6e`
- 카드 아래·위 톱니 절취선(`clip-path` 지그재그), 살짝 기울어진 배치
- 타이틀과 주문판 모두 같은 나무 레일(`#8a5a30 → #5f3a1c`)에 금속 집게로 물린 종이
- 버튼: 머스터드 `#e8a021` + 잉크색 오프셋 그림자 `2px 3px 0 #3f2a1c`
- 다이너의 어두운 배경(`#2a1a15 → #150e0c`)은 유지 — 종이가 떠 보이게 하는 장치

`www/css/style.css` 교체본이 필요하면 요청해 주세요. HTML 구조와 클래스명은 바꾸지 않아도 됩니다.

# Files

```
design_handoff_ink_art/
├── README.md                        ← 이 문서
├── www/js/art.js                    ← 덮어쓸 프로덕션 파일
└── preview/                         ← 참고용 뷰어 (게임에 옮기지 말 것)
    ├── 게임 아트 교체본.dc.html       재료·소스·요리사·굽기·재료 상자 초상
    ├── 주방과 UI 디자인.dc.html       주방 사물·바닥 테마·손님 14종·UI 목업
    ├── game-art/art.js              (뷰어가 로드하는 사본)
    └── support.js
```

원본 저장소: `Joohyung-accounting/mr-burger` (branch `main`)
